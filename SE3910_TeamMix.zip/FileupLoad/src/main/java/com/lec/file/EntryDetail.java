package com.lec.file;

import org.beanio.*;
import org.beanio.annotation.Field;
import org.beanio.annotation.Fields;
import org.beanio.annotation.Record;


@Record(maxOccurs= 18)
public class EntryDetail {

	
	@Field(at = 0, length = 1)
	private String recordTypeCode;
	@Field(at = 1, length = 2)
	private String transactionCode;
	@Field(at = 3, length = 8)
	private String routingNumber;
	@Field(at = 11, length = 1)
	private String routingNumberCredit;
	@Field(at = 12, length = 17)
	private String routingNumberAccount;
	@Field(at = 29, length = 10)
	private String amount;
	@Field(at = 39, length = 15)
	private String receiverID;
	@Field(at = 54, length = 22)
	private String reciever;
	@Field(at = 76, length = 2)
	private String discretionaryData;
	@Field(at = 78, length = 1)
	private String addendaRecord;
	@Field(at = 79, length = 15)
	private String traceNumber;
	
	
	public String getRecordTypeCode() {
		return recordTypeCode;
	}

	public void setRecordTypeCode(String recordTypeCode) {
		this.recordTypeCode = recordTypeCode;
	}

	public String getTransactionCode() {
		return transactionCode;
	}

	public void settransactionCode(String transactionCode) {
		this.transactionCode = transactionCode;
	}

	public String getRoutingNumber() {
		return routingNumber;
	}

	public void setroutingNumber(String routingNumber) {
		this.routingNumber = routingNumber;
	}

	public String getRoutingNumberCredit() {
		return routingNumberCredit;
	}

	public void setroutingNumberCredit(String routingNumberCredit) {
		this.routingNumberCredit = routingNumberCredit;
	}

	public String getroutingNumberAccount() {
		return routingNumberAccount;
	}

	public void setroutingNumberAccount(String routingNumberAccount) {
		this.routingNumberAccount = routingNumberAccount;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getreceiverID() {
		return receiverID;
	}

	public void setreceiverID(String receiverID) {
		this.receiverID = receiverID;
	}
	public String getreciever() {
		return reciever;
	}

	public void setreciever(String reciever) {
		this.reciever = reciever;
	}
	public String getdiscretionaryData() {
		return discretionaryData;
	}

	public void setdiscretionaryData(String discretionaryData) {
		this.discretionaryData = discretionaryData;
	}
	public String getaddendaRecord() {
		return addendaRecord;
	}

	public void setaddendaRecord(String addendaRecord) {
		this.addendaRecord = addendaRecord;
	}
	public String gettraceNumber() {
		return traceNumber;
	}

	public void settraceNumber(String traceNumber) {
		this.traceNumber = traceNumber;
	}
	
}
