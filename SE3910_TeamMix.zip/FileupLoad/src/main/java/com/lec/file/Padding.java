package com.lec.file;

import org.beanio.*;
import org.beanio.annotation.Field;
import org.beanio.annotation.Record;

@Record(maxOccurs=9)
public class Padding {
	
	@Field(at = 0, length = 94 )
	private String padding;

	public String getPadding() {
		return padding;
	}

	public void setPadding(String padding) {
		this.padding = padding;
	}

}
