package com.lec.file;

import org.beanio.annotation.Field;
import org.beanio.annotation.Record;

@Record(maxOccurs=1)
public class BatchHeader {

	@Field(at = 0, length = 1)
	private String recordTypeCode;
	@Field(at = 1, length = 3)
	private String serviceCode;
	@Field(at = 4, length = 16)
	private String comapanyName;
	@Field(at = 20, length = 20)
	private String discretionaryData;
	@Field(at = 40, length = 10)
	private String compIdentification;
	@Field(at = 50, length = 3)
	private String standardEntry;
	@Field(at = 53, length = 10)
	private String companyEntryDescription;
	@Field(at = 63, length = 6)
	private String companyDescriptive;
	@Field(at = 69, length = 6)
	private String effectiveEntryDate;
	@Field(at = 75, length = 3)
	private String settlementDate;
	@Field(at = 78, length = 1)
	private String originator;
	@Field(at = 79, length = 8)
	private String originationgDFI;
	@Field(at = 87, length = 7)
	private String batchNumber;
	
	
	public String getRecordTypeCode() {
		return recordTypeCode;
	}

	public void setRecordTypeCode(String recordTypeCode) {
		this.recordTypeCode = recordTypeCode;
	}

	public String getserviceCode() {
		return serviceCode;
	}

	public void setserviceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}

	public String getcomapanyName() {
		return comapanyName;
	}

	public void setcomapanyName(String comapanyName) {
		this.comapanyName = comapanyName;
	}

	public String getdiscretionaryData() {
		return discretionaryData;
	}

	public void setdiscretionaryData(String discretionaryData) {
		this.discretionaryData = discretionaryData;
	}

	public String getcompIdentification() {
		return compIdentification;
	}

	public void setcompIdentification(String compIdentification) {
		this.compIdentification = compIdentification;
	}

	public String getstandardEntry() {
		return standardEntry;
	}

	public void setstandardEntry(String standardEntry) {
		this.standardEntry = standardEntry;
	}
	public String getcompanyEntryDescription() {
		return companyEntryDescription;
	}

	public void setcompanyEntryDescription(String companyEntryDescription) {
		this.companyEntryDescription = companyEntryDescription;
	}
	public String getcompanyDescriptive() {
		return companyDescriptive;
	}

	public void setcompanyDescriptive(String companyDescriptive) {
		this.companyDescriptive = companyDescriptive;
	}
	public String geteffectiveEntryDate() {
		return effectiveEntryDate;
	}

	public void seteffectiveEntryDate(String effectiveEntryDate) {
		this.effectiveEntryDate = effectiveEntryDate;
	}
	public String getsettlementDate() {
		return settlementDate;
	}

	public void setsettlementDate(String settlementDate) {
		this.settlementDate = settlementDate;
	}
	public String getoriginator() {
		return originator;
	}

	public void setoriginator(String originator) {
		this.originator = originator;
	}
	public String getoriginationgDFI() {
		return originationgDFI;
	}

	public void setoriginationgDFI(String originationgDFI) {
		this.originationgDFI = originationgDFI;
	}
	public String getbatchNumber() {
		return batchNumber;
	}

	public void setbatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}
	
	
}
