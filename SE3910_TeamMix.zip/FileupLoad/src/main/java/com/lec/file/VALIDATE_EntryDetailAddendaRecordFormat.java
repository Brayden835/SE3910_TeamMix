package com.lec.file;

public class VALIDATE_EntryDetailAddendaRecordFormat {
	public boolean VALIDATE_recordTypeCode(String recordTypeCode) {
		//value must be 1
        if(recordTypeCode.equals("7")) return false;
        	return true;
	}
	public boolean VALIDATE_addendaTypeCode(String addendaTypeCode) {
		//value must be 1
        if(addendaTypeCode.equals("05")) return false;
        	return true;
	}
	public boolean VALIDATE_companyName(String companyName) {
        //must be alphanumeric
        if(companyName.matches("[A-Za-z0-9]+") == false) return true;
        return false;
	}
	public boolean VALIDATE_addendaSequenceNumber(String addendaSequenceNumber) {
		//must be numeric
		for(int i = 0; i < 4; i++ )
            if(Character.isDigit(addendaSequenceNumber.charAt(i)) == false) return true;
		return false;
	}
	public boolean VALIDATE_entryDetailSequenceNumber(String entryDetailSequenceNumber) {
		//must be numeric
		for(int i = 0; i < 7; i++ )
            if(Character.isDigit(entryDetailSequenceNumber.charAt(i)) == false) return true;
		return false;
	}
}
