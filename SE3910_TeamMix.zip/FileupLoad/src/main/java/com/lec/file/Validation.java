package com.lec.file;

import java.io.File;

import org.beanio.StreamFactory;

public class Validation {
	
	
	String[][] nachaData = new String[25][13]; 
	
	
	public boolean[][] validate(String file) {
		
		boolean[][] array = new boolean[25][13]; 
		
        StreamFactory factory = StreamFactory.newInstance();
        
        // locate the relative path to this project and store it in the String "path"
        //File currentDirFile = new File(".");
        //String path = currentDirFile.getAbsolutePath().toString(); 
        
        // load the mapping file
        
        // Insert your directory path below
        factory.load("C:\\Users\\Brayden\\Downloads\\file_modified13\\file_modified15\\FileupLoad\\src\\main\\java\\com\\lec\\file\\mapping.xml");
        
        org.beanio.BeanReader in =  factory.createReader("data", new File(file));
        
        // Create variable to hold each line type
        FileHeader fileheader;
        BatchHeader batchheader;
    	EntryDetail entryDetail;
    	BatchControl batchcontrol;
    	FileControl filecontrol;
    	Padding padding;
    	int numOfLines = 0; // Current num of lines read
        Object bean;
        
        
        // Read File header (line 1)  // This is done
        bean = in.read();
        numOfLines++;
        fileheader = (FileHeader) bean;
        
        //Validates fileheader (line 1)
        VALIDATE_FileHeader valfileheader = new VALIDATE_FileHeader();
        array[0][0] = valfileheader.VALIDATE_recordTypeCode(fileheader.getRecordTypeCode());
        array[0][1] = valfileheader.VALIDATE_priorityCode(fileheader.getPriorityCode());
        array[0][2] = valfileheader.VALIDATE_iDestination(fileheader.getiDestination());
        array[0][3] = valfileheader.VALIDATE_iOrigin(fileheader.getiOrigin());	
        array[0][4] = valfileheader.VALIDATE_fileCreateDate(fileheader.getFileCreateDate());
        array[0][5] = valfileheader.VALIDATE_fileCreateTime(fileheader.getFileCreateTime()); // error 13 should be 1
	    array[0][6] = valfileheader.VALIDATE_fileIDModifier(fileheader.getfileIDMod());
	    array[0][7] = valfileheader.VALIDATE_recordSize(fileheader.getrecordSize());
	    array[0][8] = valfileheader.VALIDATE_blockingFactor(fileheader.getblockingFac());
	    array[0][9] = valfileheader.VALIDATE_formatCode(fileheader.getformatCode());
		array[0][10] = valfileheader.VALIDATE_immDestName(fileheader.getiDestinationName());
		array[0][11] = valfileheader.VALIDATE_immOriginName(fileheader.getiOrginName());
		array[0][12] = valfileheader.VALIDATE_referenceCode(fileheader.getReferencecode());
    
		
        // Read Batch Header (line 2)  // This is done
        bean = (Object) bean;      
        bean = in.read();  
        numOfLines++;
        batchheader = (BatchHeader)bean;
        
        VALIDATE_CompanyBatchHeaderRecordFormat valbatchheader = new VALIDATE_CompanyBatchHeaderRecordFormat();
        array[1][0] = valbatchheader.VALIDATE_recordTypeCode(batchheader.getRecordTypeCode());
        array[1][1] = valbatchheader.VALIDATE_serviceClassCode(batchheader.getserviceCode());
        array[1][2] = valbatchheader.VALIDATE_companyName(batchheader.getcomapanyName());
        array[1][3] = valbatchheader.VALIDATE_companyDiscretionData(batchheader.getdiscretionaryData());
        array[1][4] = valbatchheader.VERIFY_companyID(batchheader.getcompIdentification());
        array[1][5] = valbatchheader.VALIDATE_standardEntryClass(batchheader.getstandardEntry());
        array[1][6] = valbatchheader.VALIDATE_companyEntryDesc(batchheader.getcompanyEntryDescription());
        array[1][7] = valbatchheader.VALIDATE_companyDescDate(batchheader.getcompanyDescriptive());
        array[1][8] = valbatchheader.VALIDATE_effectiveEntryDate(batchheader.geteffectiveEntryDate());
        array[1][9] = valbatchheader.VALIDATE_settlementDate(batchheader.getsettlementDate());
        array[1][10] = valbatchheader.VALIDATE_originStatusCode(batchheader.getoriginator());
        array[1][11] = valbatchheader.VALIDATE_originDFI_ID(batchheader.getoriginationgDFI());
        array[1][12] = valbatchheader.VALIDATE_batchNumber(batchheader.getbatchNumber());
        
        
        
        //Read each Entry Detail and Sum up Entry Details (for lines 3 -> n)
    	int debitSum = 0;
    	int creditSum = 0;
    	double routingSum =0;
    	bean = (Object) bean;
    
    	VALIDATE_EntryDetail valdentrydetail = new VALIDATE_EntryDetail();
    	int count;
    	
    	for(count = 1 ; count <= 18 ; count++) {
    		
    		bean =in.read();
            numOfLines++;
    		entryDetail = (EntryDetail)bean;
    		
    		
    		routingSum = routingSum + Double.parseDouble(entryDetail.getRoutingNumber());

    		// check if entry code is a debit (27, 28, 37, 38)
      		if((Integer.parseInt(entryDetail.getTransactionCode()) == 27 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 28 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 37 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 38 ))
	    		
      			debitSum += Integer.parseInt(entryDetail.getAmount());
      		// Else it is a credit (22, 23, 32, 33)
      		else if((Integer.parseInt(entryDetail.getTransactionCode()) == 22 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 23 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 32 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 33 ))
      			
	    		creditSum += Integer.parseInt(entryDetail.getAmount());
      		
      		if(array[count][0] == false ) array[2][0] = valdentrydetail.VALIDATE_recordTypeCode(entryDetail.getRecordTypeCode());
      		if(array[count][1] == false ) array[2][1] = valdentrydetail.VALIDATE_transactionTypeCode(entryDetail.getTransactionCode());   
      		if(array[count][2] == false )array[2][2] = valdentrydetail.VALIDATE_transactionTypeCode(entryDetail.getTransactionCode());
      		if(array[count][3] == false )array[2][3] = valdentrydetail.VALIDATE_routingNumber(entryDetail.getRoutingNumber());
      		if(array[count][4] == false )array[2][4] = valdentrydetail.VALIDATE_routingNumberCheckDigit(entryDetail. getRoutingNumberCredit());
      		if(array[count][5] == false )array[2][5] = valdentrydetail.VALIDATE_receivedInstitutionAccountNumber(entryDetail.getroutingNumberAccount());
      		if(array[count][6] == false )array[2][6] = valdentrydetail.VALIDATE_dollarAmountTransaction(entryDetail.getAmount());
      		if(array[count][7] == false )array[2][7] = valdentrydetail.VALIDATE_receiverIDNumber(entryDetail.getreceiverID());
      		if(array[count][8] == false )array[2][8] = valdentrydetail.VALIDATE_receiverName(entryDetail.getreciever());
     		if(array[count][9] == false )array[2][9] = valdentrydetail.VALIDATE_discreteData(entryDetail.getdiscretionaryData());
      		if(array[count][10] == false )array[2][10] = valdentrydetail.VALIDATE_addendaRecordIndicator(entryDetail.getaddendaRecord());
      		if(array[count][10] == false )array[2][11] = valdentrydetail.VALIDATE_traceNumber(entryDetail.gettraceNumber());
    	}
    	
    	
    	
    	
    	
    	
    		
    			
    			
    	// read batch control. THIS IS DONE
    	
    	// Read Company/Batch Control Record Format (for line n+1)
    	// must check creditSum and debitSum against corresponding credit and debit totals
        bean = (Object) bean;      
        bean = in.read();   
        numOfLines++;
        batchcontrol = (BatchControl)bean;
        
        VALIDATE_CompanyBatchControlRecordFormat valcompanycontrol = new VALIDATE_CompanyBatchControlRecordFormat();
        array[count+1][0] = valcompanycontrol.VALIDATE_recordTypeCode(batchcontrol.getRecordTypeCode());
        array[count+1][1] = valcompanycontrol.VALIDATE_serviceClassCode(batchcontrol.getServiceClassCode());
        array[count+1][2] = valcompanycontrol.VALIDATE_entryCount(batchcontrol.getEntryCount());
        array[count+1][3] = valcompanycontrol.VALIDATE_entryHash(batchcontrol.getEntryHash());
        array[count+1][4] = valcompanycontrol.VALIDATE_totalDebitEntry(batchcontrol.getTotalDebitEntry());
        array[count+1][5] = valcompanycontrol.VALIDATE_totalCreditEntry(batchcontrol.getTotalCreditEntry());
        array[count+1][6] = valcompanycontrol.VALIDATE_companyID(batchcontrol.getCompanyID(), batchheader.getcompIdentification());
        array[count+1][7] = valcompanycontrol.VALIDATE_messageAuthCode(batchcontrol.getMessageAuthCode());
        array[count+1][8] = valcompanycontrol.VALIDATE_reserve(batchcontrol.getReserve());
        array[count+1][9] = valcompanycontrol.VALIDATE_originatingDFI(batchcontrol.getOriginatingDFI());
        array[count+1][10] = valcompanycontrol.VALIDATE_batchNumber(batchcontrol.getBatchNumber());
 
        
        
        //hash error
       
    	// Read File Control Record Format (for line n+2)
        bean = (Object) bean;      
        bean = in.read();   
        numOfLines++;
        filecontrol = (FileControl)bean;
        int fileLength = Integer.parseInt(filecontrol.getBlockCount()) * 10; // The number of lines the file *should* have
    	
        VALIDATE_FileControlRecordFormat valfilecontrol = new VALIDATE_FileControlRecordFormat();
        array[count+2][0] = valfilecontrol.VALIDATE_recordTypeCode(filecontrol.getRecordTypeCode());
        array[count+2][1] = valfilecontrol.VALIDATE_batchCount(filecontrol.getBatchCount());
        array[count+2][2] = valfilecontrol.VALIDATE_blockCount(filecontrol.getBlockCount());
        array[count+2][3] = valfilecontrol.VALIDATE_entryAddendaCount(filecontrol.getEntryAddendaCount());
        array[count+2][4] = valfilecontrol.VALIDATE_entryHash(filecontrol.getEntryHash());
        array[count+2][5] = valfilecontrol.VALIDATE_totalDebitEntryDollarAmount(filecontrol.getTotalDebitEntryDollarAmount());
        array[count+2][6] = valfilecontrol.VALIDATE_totalCreditEntryDollarAmount(filecontrol.getTotalCreditEntryDollarAmount());
        array[count+2][7] = valfilecontrol.VALIDATE_reserved(filecontrol.getReserved());
        
        
    	
    	// Read Padding lines of zero's for remaining lines until filecontrol.getBlockCount() is divisble by 10 (count % 10 == 0)
    	// Anywhere from 0 (already divisible by 10) 
    	// up to 9 (needs to have 9 additional lines to be divisable by 10)
        bean = (Object)bean;
        while((bean=in.read()) != null ) {
        	padding = (Padding)bean;
        	numOfLines++;
        }
        

        
        return array;
	}
	
	

	
	
	public String[][] NachaFile(String file) {
		
		String[][] array = new String[25][13]; 
		
        StreamFactory factory = StreamFactory.newInstance();
        
        // locate the relative path to this project and store it in the String "path"
        //File currentDirFile = new File(".");
        //String path = currentDirFile.getAbsolutePath().toString(); 
        
        // load the mapping file
        
        // Insert your directory path below
        factory.load("C:\\Users\\Brayden\\Downloads\\file_modified13\\FileupLoad\\src\\main\\java\\com\\lec\\file\\mapping.xml");
        
        org.beanio.BeanReader in =  factory.createReader("data", new File(file));
        
        // Create variable to hold each line type
        FileHeader fileheader;
        BatchHeader batchheader;
    	EntryDetail entryDetail;
    	BatchControl batchcontrol;
    	FileControl filecontrol;
    	Padding padding;
    	int numOfLines = 0; // Current num of lines read
        Object bean;
        
        
        // Read File header (line 1)  // This is done
        bean = in.read();
        numOfLines++;
        fileheader = (FileHeader) bean;
        
        //Validates fileheader (line 1)
        VALIDATE_FileHeader valfileheader = new VALIDATE_FileHeader();
        array[0][0] = fileheader.getRecordTypeCode();
        array[0][1] = fileheader.getPriorityCode();
        array[0][2] = fileheader.getiDestination();
        array[0][3] = fileheader.getiOrigin();	
        array[0][4] = fileheader.getFileCreateDate();
        array[0][5] = fileheader.getFileCreateTime(); // error 13 should be 1
	    array[0][6] = fileheader.getfileIDMod();
	    array[0][7] = fileheader.getrecordSize();
	    array[0][8] = fileheader.getblockingFac();
	    array[0][9] = fileheader.getformatCode();
		array[0][10] = fileheader.getiDestinationName();
		array[0][11] = fileheader.getiOrginName();
		array[0][12] = fileheader.getReferencecode();
    
		
        // Read Batch Header (line 2)  // This is done
        bean = (Object) bean;      
        bean = in.read();  
        numOfLines++;
        batchheader = (BatchHeader)bean;
        
        VALIDATE_CompanyBatchHeaderRecordFormat valbatchheader = new VALIDATE_CompanyBatchHeaderRecordFormat();
        array[1][0] = batchheader.getRecordTypeCode();
        array[1][1] = batchheader.getserviceCode();
        array[1][2] = batchheader.getcomapanyName();
        array[1][3] = batchheader.getdiscretionaryData();
        array[1][4] = batchheader.getcompIdentification();
        array[1][5] = batchheader.getstandardEntry();
        array[1][6] = batchheader.getcompanyEntryDescription();
        array[1][7] = batchheader.getcompanyDescriptive();
        array[1][8] = batchheader.geteffectiveEntryDate();
        array[1][9] = batchheader.getsettlementDate();
        array[1][10] = batchheader.getoriginator();
        array[1][11] = batchheader.getoriginationgDFI();
        array[1][12] = batchheader.getbatchNumber();
        
        
        
        //Read each Entry Detail and Sum up Entry Details (for lines 3 -> n)
    	int debitSum = 0;
    	int creditSum = 0;
    	double routingSum =0;
    	bean = (Object) bean;
    
    	VALIDATE_EntryDetail valdentrydetail = new VALIDATE_EntryDetail();
    	int count;
    	
    	for(count = 2 ; count <= 19 ; count++) {
    		
    		bean =in.read();
            numOfLines++;
    		entryDetail = (EntryDetail)bean;
    		
    		
    		routingSum = routingSum + Double.parseDouble(entryDetail.getRoutingNumber());

    		// check if entry code is a debit (27, 28, 37, 38)
      		if((Integer.parseInt(entryDetail.getTransactionCode()) == 27 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 28 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 37 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 38 ))
	    		
      			debitSum += Integer.parseInt(entryDetail.getAmount());
      		// Else it is a credit (22, 23, 32, 33)
      		else if((Integer.parseInt(entryDetail.getTransactionCode()) == 22 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 23 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 32 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 33 ))
      			
	    		creditSum += Integer.parseInt(entryDetail.getAmount());
      		
      		array[count][0] = entryDetail.getRecordTypeCode();
      		array[count][1] = entryDetail.getTransactionCode();   
      		array[count][2] = entryDetail.getRoutingNumber();
      		array[count][3] = entryDetail. getRoutingNumberCredit();
      		array[count][4] = entryDetail.getroutingNumberAccount();
      		array[count][5] = entryDetail.getAmount();
      		array[count][6] = entryDetail.getreceiverID();
      		array[count][7] = entryDetail.getreciever();
     		array[count][8] = entryDetail.getdiscretionaryData();
      		array[count][9] = entryDetail.getaddendaRecord();
      		array[count][10] = entryDetail.gettraceNumber();
    	}
    	
    	
    	
    	
    	
    	
    		
    			
    			
    	// read batch control. THIS IS DONE
    	
    	// Read Company/Batch Control Record Format (for line n+1)
    	// must check creditSum and debitSum against corresponding credit and debit totals
        bean = (Object) bean;      
        bean = in.read();   
        numOfLines++;
        batchcontrol = (BatchControl)bean;
        
        VALIDATE_CompanyBatchControlRecordFormat valcompanycontrol = new VALIDATE_CompanyBatchControlRecordFormat();
        array[count+1][0] = batchcontrol.getRecordTypeCode();
        array[count+1][1] = batchcontrol.getServiceClassCode();
        array[count+1][2] = batchcontrol.getEntryCount();
        array[count+1][3] = batchcontrol.getEntryHash();
        array[count+1][4] = batchcontrol.getTotalDebitEntry();
        array[count+1][5] = batchcontrol.getTotalCreditEntry();
        array[count+1][6] = batchcontrol.getCompanyID();
        array[count+1][7] = batchcontrol.getMessageAuthCode();
        array[count+1][8] = batchcontrol.getReserve();
        array[count+1][9] = batchcontrol.getOriginatingDFI();
        array[count+1][10] = batchcontrol.getBatchNumber();
 
        
        
    	
    	// Read File Control Record Format (for line n+2)
        bean = (Object) bean;      
        bean = in.read();   
        numOfLines++;
        filecontrol = (FileControl)bean;
        int fileLength = Integer.parseInt(filecontrol.getBlockCount()) * 10; // The number of lines the file *should* have
    	
        VALIDATE_FileControlRecordFormat valfilecontrol = new VALIDATE_FileControlRecordFormat();
        array[count+2][0] = filecontrol.getRecordTypeCode();
        array[count+2][1] = filecontrol.getBatchCount();
        array[count+2][2] = filecontrol.getBlockCount();
        array[count+2][3] = filecontrol.getEntryAddendaCount();
        array[count+2][4] = filecontrol.getEntryHash();
        array[count+2][5] = filecontrol.getTotalDebitEntryDollarAmount();
        array[count+2][6] = filecontrol.getTotalCreditEntryDollarAmount();
        array[count+2][7] = filecontrol.getReserved();
        
        
    	
    	// Read Padding lines of zero's for remaining lines until filecontrol.getBlockCount() is divisble by 10 (count % 10 == 0)
    	// Anywhere from 0 (already divisible by 10) 
    	// up to 9 (needs to have 9 additional lines to be divisable by 10)
        bean = (Object)bean;
        while((bean=in.read()) != null ) {
        	padding = (Padding)bean;
        	numOfLines++;
        }
        
        
               
        
        for(int i = 0; i < 25; i++) {
        	for(int j = 0; j < 13; j++) {
        		nachaData[i][j] = array[i][j];
        	}        	
        }
        
        return array;
	}
	
	
 
	
	
	
	public int amountError() {
		
		// Checks hash error between routing Sum of Entries and 
		// the hashTotal in 
		
		// check if entry code is a debit (27, 28, 37, 38)

		
		
		int debitSum = 0;
		int creditSum = 0;
		
		int DebitEntry = 0;
		int CreditEntry = 0;
		
		for (int i = 2; i < 24 ; i++) {
			
			System.out.println(nachaData[i][0]);
			

			
			
			
			if( nachaData[i][0] !=null) {

			
			if(Integer.parseInt(nachaData[i][0]) == 6) {

		  		if(Integer.parseInt(nachaData[i][1]) == 27 || 
		  	    		Integer.parseInt(nachaData[i][1]) == 28 || 
		  	    		Integer.parseInt(nachaData[i][1]) == 37 || 
		  	    		Integer.parseInt(nachaData[i][1]) == 38 ) {
	  	    		
		  	  			debitSum += Integer.parseInt(nachaData[i][5]);
		  			}
		  	  		// Else it is a credit (22, 23, 32, 33)
		  	  		else if(Integer.parseInt(nachaData[i][1]) == 22 || 
		  	    		Integer.parseInt(nachaData[i][1]) == 23 || 
		  	    		Integer.parseInt(nachaData[i][1]) == 32 || 
		  	    		Integer.parseInt(nachaData[i][1]) == 33 ) {
		  	    		creditSum += Integer.parseInt(nachaData[i][5]);
		  	  		}
			}
 
			if(Integer.parseInt(nachaData[i][0]) == 8) {
				System.out.println(" --- "+ nachaData[i][4]);
				System.out.println(" --- "+ nachaData[i][5]);
				DebitEntry =  Integer.parseInt(nachaData[i][4]);
				CreditEntry =  Integer.parseInt(nachaData[i][5]);
			}
			}
 
		}
		
		System.out.println("****" + creditSum + "||" +  CreditEntry);
		System.out.println("****" + debitSum + "||" +  DebitEntry);

		/*
		if(routingSum == hashEntry) {
			
			return 0; 
		}else{ 
		
			return 1;	
		}
		
		*/
		
		if(debitSum == DebitEntry && creditSum == CreditEntry) {
			return 0;
		}else {
			return 1;
		}
		
	}
	
	
	
	
	public int hashError() {
		
		// Checks hash error between routing Sum of Entries and 
		// the hashTotal in 
		
		
		System.out.println(nachaData[2][0]);
		System.out.println(nachaData[2][3]);
		System.out.println(nachaData[2][2]);
		
		
		double ControlRoutingSum = 0;
		double routingSum = 0;
		
		for (int i = 2; i < 24 ; i++) {
			
			System.out.println(nachaData[i][0]);
			
			if( nachaData[i][0] !=null) {

				
				
				System.out.println(" *** "+ nachaData[i][3]);	
				
				
			if(Integer.parseInt(nachaData[i][0]) == 6) {

				routingSum = routingSum + Double.parseDouble(nachaData[i][2]);
			}
 
			if(Integer.parseInt(nachaData[i][0]) == 8) {
				System.out.println(" --- "+ nachaData[i][3]);	
				ControlRoutingSum =  Double.parseDouble(nachaData[i][3]);
			}
			}
 
		}
		
		System.out.println(ControlRoutingSum + "||" +  routingSum);

		/*
		if(routingSum == hashEntry) {
			
			return 0; 
		}else{ 
		
			return 1;	
		}
		
		*/
		
		if(ControlRoutingSum == routingSum ) {
			return 0;
		}else {
			return 1;
		}
		
	}
	
	
}
