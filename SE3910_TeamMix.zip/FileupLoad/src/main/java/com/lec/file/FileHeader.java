package com.lec.file;
import org.beanio.*;
import org.beanio.annotation.Field;
import org.beanio.annotation.Fields;
import org.beanio.annotation.Record;

import java.io.*;

@Record(maxOccurs=1)

public class FileHeader {
	
	@Field(at = 0, length = 1)
	private String recordTypeCode;
	@Field(at = 1, length = 2)
	private String priorityCode;
	@Field(at = 3, length = 10)
	private String iDestination;
	@Field(at = 13, length = 10)
	private String iOrigin;
	@Field(at = 23, length = 6)
	private String fileCDate;
	@Field(at = 29, length = 4)
	private String fileCTime;
	@Field(at = 33, length = 1)
	private String fileIDMod;
	@Field(at = 34, length = 3)
	private String recordSize;
	@Field(at = 37, length = 2)
	private String blockingFac;
	@Field(at = 39, length = 1)
	private String formatCode;
	@Field(at = 40, length = 23)
	private String iDestinationName;
	@Field(at = 63, length = 23)
	private String iOrginName;
	@Field(at = 86, length = 8)
	private String referencecode;
	
	
	public String getRecordTypeCode() {
		return recordTypeCode;
	}

	public void setRecordTypeCode(String recordTypeCode) {
		this.recordTypeCode = recordTypeCode;
	}

	public String getPriorityCode() {
		return priorityCode;
	}

	public void setPriorityCode(String priorityCode) {
		this.priorityCode = priorityCode;
	}

	public String getiDestination() {
		return iDestination;
	}

	public void setiDestination(String iDestination) {
		this.iDestination = iDestination;
	}

	public String getiOrigin() {
		return iOrigin;
	}

	public void setiOrigin(String iOrigin) {
		this.iOrigin = iOrigin;
	}

	public String getFileCreateDate() {
		return fileCDate;
	}

	public void setFileCreateDate(String fileCDate) {
		this.fileCDate = fileCDate;
	}

	public String getFileCreateTime() {
		return fileCDate;
	}

	public void setFileCreateTime(String fileCTime) {
		this.fileCTime = fileCTime;
	}
	public String getfileIDMod() {
		return fileIDMod;
	}

	public void setfileIDMod(String fileIDMod) {
		this.fileIDMod = fileIDMod;
	}
	public String getrecordSize() {
		return recordSize;
	}

	public void setrecordSize(String recordSize) {
		this.recordSize = recordSize;
	}
	public String getblockingFac() {
		return blockingFac;
	}

	public void setblockingFac(String blockingFac) {
		this.blockingFac = blockingFac;
	}
	public String getformatCode() {
		return formatCode;
	}

	public void setformatCode(String formatCode) {
		this.formatCode = formatCode;
	}
	public String getiDestinationName() {
		return iDestinationName;
	}

	public void setiDestinationName(String iDestinationName) {
		this.iDestinationName = iDestinationName;
	}
	public String getiOrginName() {
		return iOrginName;
	}

	public void setiOrginName(String iOrginName) {
		this.iOrginName = iOrginName;
	}
	public String getReferencecode() {
		return referencecode;
	}

	public void setReferencecode(String referencecode) {
		this.referencecode = referencecode;
	}

	
	
}
