package com.lec.file;

import java.util.regex.*;

public class VALIDATE_FileHeader {
//      public VALIDATE_FileHeader() {
//
//      }

        //TRUE indicates ERROR
        //FALSE indicates NO ERROR

        public boolean VALIDATE_recordTypeCode (String recordTypeCode) {
                if(recordTypeCode.equals("1")) return false;
                return true;
        }
        public boolean VALIDATE_priorityCode (String priorityCode) {
                if(priorityCode.equals("01")) return false;
                return true;
        }
        public boolean VALIDATE_iDestination (String iDestination) {
        	
                if(iDestination.matches(" 101000019") == true) return false;
                return true;
        }
        public boolean VALIDATE_iOrigin (String iOrigin) {
                //first character must be space
               // if(iOrigin.charAt(0) != ' ') return true;

        		// Should have leading space?
        	
                //and others must be numeric
                for(int i = 0; i <= 9; i++ )
                        if(Character.isDigit(iOrigin.charAt(i)) == false) return true;
                return false;
        }
        public boolean VALIDATE_fileCreateDate (String fileCreateDate) {
                //all characters must be numeric
                for(int i = 0; i <= 5; i++ )
                        if(Character.isDigit(fileCreateDate.charAt(i)) == false) return true;

                //second two (MM) must be numeric within values 1 and 12
                int tens = 10 * Character.getNumericValue(fileCreateDate.charAt(2));
                int ones = Character.getNumericValue(fileCreateDate.charAt(3));
                int month = tens + ones;
                if(month > 12 || month < 1) return true;

                //last two (DD) must be numeric values within values 1 and 31
                tens = 10 * Character.getNumericValue(fileCreateDate.charAt(4));
                ones = Character.getNumericValue(fileCreateDate.charAt(5));
                int day = tens + ones;
                if(day > 31 || day < 1) return true;

                //else
                return false;
        }

        public boolean VALIDATE_fileCreateTime (String fileCreateTime) {
                //all characters must be numeric
                for(int i = 0; i <= 3; i++ )
                        if(Character.isDigit(fileCreateTime.charAt(i)) == false) return true;

                //first two (HH) must be numeric within values 1 and 24
                int tens = 10 * Character.getNumericValue(fileCreateTime.charAt(0));
                int ones = Character.getNumericValue(fileCreateTime.charAt(1));
                int hour = tens + ones;
                if(hour > 24 || hour < 1) return true;

                //second two (MM) must be numeric within values 0 and 59
                tens = 10 * Character.getNumericValue(fileCreateTime.charAt(2));
                ones = Character.getNumericValue(fileCreateTime.charAt(1)); // was 13 should be 1
                int minute = tens + ones;
                if(minute > 59 || minute < 0) return true;

                //else
                return false;
        }

        public boolean VALIDATE_fileIDModifier (String fileIDModifier) {
                //must be alphanumeric
                if(fileIDModifier.matches("[A-Za-z0-9]+") == false) return true;
                return false;
        }

        public boolean VALIDATE_recordSize (String recordSize) {
                if(recordSize.equals("094")) return false;
                return true;
        }

        public boolean VALIDATE_blockingFactor (String blockingFactor) {
                if(blockingFactor.equals("10")) return false;
                return true;
        }

        public boolean VALIDATE_formatCode (String formatCode) {
                if(formatCode.equals("1")) return false;
                return true;
        }

        public boolean VALIDATE_immDestName (String immDestName) {
                if(immDestName.equals("Testing1 Bank")) return false;
                return true;
        }

        public boolean VALIDATE_immOriginName (String immOriginName) {
                //must be alphanumeric
        	
        	Boolean check = Pattern.matches("^[a-zA-Z0-9_ ]*$",immOriginName);
        	if(check == false) return true;
      
            return false;
        }

        public boolean VALIDATE_referenceCode (String referenceCode) {
                //must be alphanumeric
        	Boolean check = Pattern.matches("^[a-zA-Z0-9_ ]*$",referenceCode);

        	if(check == false) return true;
            
            return false;
        }
}
