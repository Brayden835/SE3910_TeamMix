package com.lec.file;

import org.beanio.*;
import org.beanio.annotation.Field;
import org.beanio.annotation.Fields;
import org.beanio.annotation.Record;
import java.io.*;


@Record(maxOccurs=1)
public class BatchControl {
	
	@Field(at = 0, length = 1)
	private String recordTypeCode;
	
	@Field(at = 1, length = 3)
	private String serviceClassCode;
	
	@Field(at = 4, length = 6)
	private String entryCount;
	
	@Field(at = 10, length = 10)
	private String entryHash;
	
	@Field(at = 20, length = 12)
	private String totalDebitEntry;
	
	@Field(at = 32, length = 12)
	private String totalCreditEntry;
	
	@Field(at = 44, length = 10)
	private String companyID;
	
	@Field(at = 54, length = 19)
	private String messageAuthCode;
	
	@Field(at = 73, length = 6)
	private String reserve;
	
	@Field(at = 79, length = 8)
	private String originatingDFI;
	
	@Field(at = 87, length = 7)
	private String batchNumber;

	public String getRecordTypeCode() {
		return recordTypeCode;
	}

	public void setRecordTypeCode(String recordTypeCode) {
		this.recordTypeCode = recordTypeCode;
	}

	public String getServiceClassCode() {
		return serviceClassCode;
	}

	public void setServiceClassCode(String serviceClassCode) {
		this.serviceClassCode = serviceClassCode;
	}

	public String getEntryCount() {
		return entryCount;
	}

	public void setEntryCount(String entryCount) {
		this.entryCount = entryCount;
	}

	public String getEntryHash() {
		return entryHash;
	}

	public void setEntryHash(String entryHash) {
		this.entryHash = entryHash;
	}

	public String getTotalDebitEntry() {
		return totalDebitEntry;
	}

	public void setTotalDebitEntry(String totalDebitEntry) {
		this.totalDebitEntry = totalDebitEntry;
	}

	public String getTotalCreditEntry() {
		return totalCreditEntry;
	}

	public void setTotalCreditEntry(String totalCreditEntry) {
		this.totalCreditEntry = totalCreditEntry;
	}

	public String getCompanyID() {
		return companyID;
	}

	public void setCompanyID(String companyID) {
		this.companyID = companyID;
	}

	public String getMessageAuthCode() {
		return messageAuthCode;
	}

	public void setMessageAuthCode(String messageAuthCode) {
		this.messageAuthCode = messageAuthCode;
	}

	public String getReserve() {
		return reserve;
	}

	public void setReserve(String reserve) {
		this.reserve = reserve;
	}

	public String getOriginatingDFI() {
		return originatingDFI;
	}

	public void setOriginatingDFI(String originatingDFI) {
		this.originatingDFI = originatingDFI;
	}

	public String getBatchNumber() {
		return batchNumber;
	}

	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}
	
	 
}

