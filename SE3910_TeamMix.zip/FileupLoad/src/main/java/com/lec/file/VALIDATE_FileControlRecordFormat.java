package com.lec.file;

public class VALIDATE_FileControlRecordFormat {
	   //TRUE indicates ERROR
    //FALSE indicates NO ERROR
	
	public boolean VALIDATE_recordTypeCode(String recordTypeCode) {
		//value must be 1
        if(recordTypeCode.equals("9")) return false;
        	return true;
	}
	public boolean VALIDATE_batchCount(String batchCount) {
		//must be numeric
        for(int i = 0; i < 6; i++ )
            if(Character.isDigit(batchCount.charAt(i)) == false) return true		;
    return false;
	}
	public boolean VALIDATE_blockCount(String blockCount) {
		//must be numeric
        for(int i = 0; i < 6; i++ )
            if(Character.isDigit(blockCount.charAt(i)) == false) return true;
    return false;
	}
	public boolean VALIDATE_entryAddendaCount(String entryAddendaCount) {
		//must be numeric
        for(int i = 0; i < 8; i++ )
            if(Character.isDigit(entryAddendaCount.charAt(i)) == false) return true;
    return false;
	}
	public boolean VALIDATE_entryHash(String entryHash) {
		//must be numeric
        for(int i = 0; i < 10; i++ )
            if(Character.isDigit(entryHash.charAt(i)) == false) return true;
    return false;
	}
	public boolean VALIDATE_totalDebitEntryDollarAmount(String totalDebitEntryDollarAmount) {
		//must be numeric
        for(int i = 0; i < 12; i++ )
            if(Character.isDigit(totalDebitEntryDollarAmount.charAt(i)) == false) return true;
    return false;
	}
	public boolean VALIDATE_totalCreditEntryDollarAmount(String totalCreditEntryDollarAmount) {
		//must be numeric
        for(int i = 0; i < 12; i++ )
            if(Character.isDigit(totalCreditEntryDollarAmount.charAt(i)) == false) return true;
    return false;
	}
	public boolean VALIDATE_reserved(String reserved) {
        //must be blanks
        if(reserved.isEmpty() == false) return true;
        return false;
	}	
}
