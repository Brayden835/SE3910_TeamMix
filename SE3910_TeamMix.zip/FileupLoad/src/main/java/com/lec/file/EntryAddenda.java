package com.lec.file;
import org.beanio.*;
import org.beanio.annotation.Field;
import org.beanio.annotation.Record;


@Record(maxOccurs=1)
public class EntryAddenda {
	@Field(at=0,length=1)
	private String recordTypeCode;
	
	@Field(at=1,length=2)
	private String addendaTypeCode;
	
	@Field(at=3,length=80)
	private String paymentRelateInformation;
	
	@Field(at=83,length=4)
	private String addendaSequenceNumber;
	
	@Field(at=87,length=7)
	private String entryDetailSequenceNumber;

	public String getRecordTypeCode() {
		return recordTypeCode;
	}

	public void setRecordTypeCode(String recordTypeCode) {
		this.recordTypeCode = recordTypeCode;
	}

	public String getAddendaTypeCode() {
		return addendaTypeCode;
	}

	public void setAddendaTypeCode(String addendaTypeCode) {
		this.addendaTypeCode = addendaTypeCode;
	}

	public String getPaymentRelateInformation() {
		return paymentRelateInformation;
	}

	public void setPaymentRelateInformation(String paymentRelateInformation) {
		this.paymentRelateInformation = paymentRelateInformation;
	}

	public String getAddendaSequenceNumber() {
		return addendaSequenceNumber;
	}

	public void setAddendaSequenceNumber(String addendaSequenceNumber) {
		this.addendaSequenceNumber = addendaSequenceNumber;
	}

	public String getEntryDetailSequenceNumber() {
		return entryDetailSequenceNumber;
	}

	public void setEntryDetailSequenceNumber(String entryDetailSequenceNumber) {
		this.entryDetailSequenceNumber = entryDetailSequenceNumber;
	}
	
	
	
	
	
}
