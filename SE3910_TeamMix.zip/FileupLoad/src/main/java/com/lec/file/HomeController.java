package com.lec.file;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.StringJoiner;

@Controller
public class HomeController {

	// Get relative file path and store it as String "path"
    //public static File currentDirFile = new File("."); // file object pointing at project
    //public static String path = currentDirFile.getAbsolutePath().toString(); // get file path as string
	
	//Save the uploaded file to this folder
    private static String UPLOADED_FOLDER = "C://temp//"; // Make sure you have temp directory
    private String filename;

    @GetMapping("/")
    public String index() {
        return "upload";
    }

    //@RequestMapping(value = "/upload", method = RequestMethod.POST)
    @PostMapping("/upload") // //new annotation since 4.3
    public String singleFileUpload(@RequestParam("file") MultipartFile file,
                                   RedirectAttributes redirectAttributes) {

        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
            return "redirect:uploadStatus";
        }

        try {

            // Get the file and save it somewhere
            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

            redirectAttributes.addFlashAttribute("message", 
                        "You successfully uploaded '" + file.getOriginalFilename() + "'");
            
            filename = file.getOriginalFilename();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return "redirect:/uploadStatus";
    }

    @GetMapping("/uploadStatus")
    public String uploadStatus() {
        return "uploadStatus";
    }
    
    
    //@RequestMapping(value = "/upload", method = RequestMethod.POST)
    @PostMapping("/validate") // //new annotation since 4.3
    public String validate(Model model) {

 
    	boolean errorcodes[][] = new boolean[25][13];
    	Validation v = new Validation();
    	errorcodes = v.validate(UPLOADED_FOLDER + filename);
    	String errors = "";
    	String[] formats = {"File Record Header", "Batch Header Record","Entry Detail","Batch Control Record", "File Control Record"};
    	
    	
    	/*
    	for(int i = 0; i < 5; i++)
    		for(int j = 0; j < 13; j++) 
    			if(errorcodes[i][j]) {
    				errors += "Error at " + formats[i] + " field " + (j+1) +"<br>";
    				
    			}
    	*/

    	String data[][] = new String[25][13];
        data = v.NachaFile(UPLOADED_FOLDER + filename);
    	

        int hashcode = 0;
        hashcode = v.hashError();
        String hashMsg = null;
        
        if(hashcode == 1) {
        	
        	hashMsg =  "Hash Error!!";
        	model.addAttribute("hashError", hashMsg);
        }
        
       
        
        int amountcode = 0;
        amountcode = v.amountError();
        String amountMsg = null;
        
        if(amountcode == 1) {
        	
        	amountMsg =  "Amount Error!!";
        	model.addAttribute("amountError", amountMsg);
        }
       
        String noErrorMsg = "No Errors Found";
        
        if(amountcode == 0 && hashcode == 0)
        	
        	
        	model.addAttribute("noError", noErrorMsg);
        
        
       
    	model.addAttribute("error", errorcodes);
    	model.addAttribute("data", data);
    	
    	return "validateResult";
    }
    
    @PostMapping("/NewFile")
    public String NewFile() {
        return "redirect:/";
    }
    
    
    
    

}