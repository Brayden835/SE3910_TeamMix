package com.lec.file;

import java.util.regex.Pattern;

public class VALIDATE_CompanyBatchControlRecordFormat {
    //TRUE indicates ERROR
    //FALSE indicates NO ERROR
	
	public boolean VALIDATE_recordTypeCode(String recordTypeCode) {
		//value must be 1
        if(recordTypeCode.equals("8")) return false;
        	return true;
	}
	
	public boolean VALIDATE_serviceClassCode(String serviceClassCode) {
		//must be numeric
        for(int i = 0; i < 3; i++ )
            if(Character.isDigit(serviceClassCode.charAt(i)) == false) return true;
    return false;
	}
	
	public boolean VALIDATE_entryCount(String entryCount) {
		//must be numeric
        for(int i = 0; i < 6; i++ )
            if(Character.isDigit(entryCount.charAt(i)) == false) return true;
    return false;
	}
	
	public boolean VALIDATE_entryHash(String entryHash) {
		//must be numeric
		for(int i = 0; i < 10; i++)
			if(Character.isDigit(entryHash.charAt(i)) == false) return true;
	    return false;
	}
	
	public boolean VALIDATE_totalDebitEntry(String totalDebitEntry) {
		//must be numeric
		for(int i = 0; i < 12; i++)
			if(Character.isDigit(totalDebitEntry.charAt(i)) == false) return true;
	    return false;
	}	
	
	public boolean VALIDATE_totalCreditEntry(String totalCreditEntry) {
		//must be numeric
		for(int i = 0; i < 12; i++)
			if(Character.isDigit(totalCreditEntry.charAt(i)) == false) return true;
	    return false;
	}	
	public boolean VALIDATE_companyID(String verify_companyID, String header_id) {
		//first must be alphanumeric
//        if(verify_companyID.matches("[A-Za-z0-9]+") == false) return true;
//		//rest must be numeric
//		for(int i = 1; i < 9; i++)
//			if(Character.isDigit(verify_companyID.charAt(i)) == false) return true;
	    //must be identical to field 5 of company/batch header record
        if(verify_companyID.equals(header_id)) return false;
	    return true;
	}	
	
	public boolean VALIDATE_messageAuthCode(String messageAuthCode) {
        //must be alphanumeric
		Boolean check = Pattern.matches("^[a-zA-Z0-9_ ]*$",messageAuthCode);
    	if(check == false) return true;
    	return false;
	}
	
	public boolean VALIDATE_reserve(String reserve) {
        //must be blanks
    
        return false;
	}
	
	public boolean VALIDATE_originatingDFI(String originatingDFI) {
        //must be blanks
       
        return false;
	}
	
	public boolean VALIDATE_batchNumber(String batchNumber) {
		//must be numeric
        for(int i = 0; i < 7; i++ )
            if(Character.isDigit(batchNumber.charAt(i)) == false) return true;
    return false;
	}
}
