package com.lec.file;

import org.beanio.*;
import org.beanio.annotation.Field;
import org.beanio.annotation.Record;

@Record(maxOccurs=1)
public class FileControl {
	
	@Field(at = 0, length = 1)
	private String recordTypeCode;
	
	@Field(at = 1, length = 6)
	private String batchCount;
	
	@Field(at = 7, length = 6)
	private String blockCount;
	
	@Field(at = 13, length = 8)
	private String entryAddendaCount;
	
	@Field(at = 21, length = 10)
	private String entryHash;
	
	@Field(at = 31, length = 12)
	private String totalDebitEntryDollarAmount;
	
	@Field(at = 43, length = 12)
	private String totalCreditEntryDollarAmount;
	
	@Field(at = 55, length = 39)
	private String reserved;

	public String getRecordTypeCode() {
		return recordTypeCode;
	}

	public void setRecordTypeCode(String recordTypeCode) {
		this.recordTypeCode = recordTypeCode;
	}

	public String getBatchCount() {
		return batchCount;
	}

	public void setBatchCount(String batchCount) {
		this.batchCount = batchCount;
	}

	public String getBlockCount() {
		return blockCount;
	}

	public void setBlockCount(String blockCount) {
		this.blockCount = blockCount;
	}

	public String getEntryAddendaCount() {
		return entryAddendaCount;
	}

	public void setEntryAddendaCount(String entryAddendaCount) {
		this.entryAddendaCount = entryAddendaCount;
	}

	public String getEntryHash() {
		return entryHash;
	}

	public void setEntryHash(String entryHash) {
		this.entryHash = entryHash;
	}

	public String getTotalDebitEntryDollarAmount() {
		return totalDebitEntryDollarAmount;
	}

	public void setTotalDebitEntryDollarAmount(String totalDebitEntryDollarAmount) {
		this.totalDebitEntryDollarAmount = totalDebitEntryDollarAmount;
	}

	public String getTotalCreditEntryDollarAmount() {
		return totalCreditEntryDollarAmount;
	}

	public void setTotalCreditEntryDollarAmount(String totalCreditEntryDollarAmount) {
		this.totalCreditEntryDollarAmount = totalCreditEntryDollarAmount;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}
	
	
	
	
}
