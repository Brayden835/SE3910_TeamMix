package com.lec.file;

import java.util.regex.Pattern;

public class VALIDATE_CompanyBatchHeaderRecordFormat {

	public boolean VALIDATE_recordTypeCode(String recordTypeCode) {
        if(recordTypeCode.equals("5")) return false;
        return true;
	}		
	
	public boolean VALIDATE_serviceClassCode(String serviceClassCode) {
		//must be numeric
		for(int i = 1; i < 3; i++ )
            if(Character.isDigit(serviceClassCode.charAt(i)) == false) return true;
		return false;
	}
	
	public boolean VALIDATE_companyName(String companyName) {
        //must be alphanumeric
        if(companyName.matches("[A-Za-z0-9]+") == false) return true;
        return false;
	}
	
	public boolean VALIDATE_companyDiscretionData(String companyDiscretionData) {
        //must be alphanumeric
		
	  	Boolean check = Pattern.matches("^[a-zA-Z0-9_ ]*$",companyDiscretionData);
    	if(check == false) return true;

        return false;
	}
	
	public boolean VERIFY_companyID(String companyID) {
		//first must be alphanumeric
		Boolean check = Pattern.matches("^[a-zA-Z0-9_ ]*$",companyID);
    	if(check == false) return true;
    	
    	String s = companyID.substring(1);
		Boolean check2 = Pattern.matches("^[0-9]",s);
    	if(check == false) return true;
		//rest must be numeric
		//for(int i = 1; i <= 9; i++)
			//if(Character.isDigit(companyID.charAt(i)) == false) return true;
		return false;
	}
	
	public boolean VALIDATE_standardEntryClass(String standardEntryClass) {
		//alphanumeric
		if(standardEntryClass.matches("[A-Za-z0-9]+") == false) return true;
    	return false;		
	}
	public boolean VALIDATE_companyEntryDesc(String companyEntryDesc) {
		//alphanumeric
		if(companyEntryDesc.matches("[A-Za-z0-9]+") == false) return true;
	    	return false;		
	}	
	public boolean VALIDATE_companyDescDate(String companyDescDate) {
		//alphanumeric
		if(companyDescDate.matches("[A-Za-z0-9]+") == false) return true;
    	return false;		
	}
	public boolean VALIDATE_effectiveEntryDate(String effectiveEntryDate) {
        //all characters must be numeric
		
		// year
		String s1 = effectiveEntryDate.substring(0,1);
		Boolean check1 = Pattern.matches("^([0-9])",s1);
		if(check1 == false) return true;
		// month	
    	String s2 = effectiveEntryDate.substring(2,3);
		Boolean check2 = Pattern.matches("^([0-9]|1[0-2])",s2);
		if(check2 == false) return true;
		// day
		String s3 = effectiveEntryDate.substring(4,5);
		Boolean check3 = Pattern.matches("^([0-9]|1[0-9]|2[0-9]|3[0-1])",s3);
		if(check3 == false) return true;
		
        return false;
	}
	
	public boolean VALIDATE_settlementDate(String settlementDate) {
		//blank
		if(settlementDate.isEmpty() == false) return true;
	        return false;
		}
	
	public boolean VALIDATE_originStatusCode(String originStatusCode) {
		//equals 1
		if(originStatusCode.equals("1")) return false;
	        return true;
		}	
	public boolean VALIDATE_originDFI_ID(String originDFI_ID) {
		//blank
		return false;
		}
	public boolean VALIDATE_batchNumber(String batchNumber) {
		//must be numeric
		for(int i = 0; i < 7; i++)
            if(Character.isDigit(batchNumber.charAt(i)) == false) return true;
		return false;
	}
}
