package com.lec.file;

import java.io.File;

import org.beanio.StreamFactory;

public class Validation2 {
	
	public FileHeader fileheader;
    public BatchHeader batchheader;
	public EntryDetail entryDetail;
	public BatchControl batchcontrol;
	public FileControl filecontrol;
	public Padding padding;
	public int numOfLines; // Current num of lines read
    public Object bean;
    public int creditSum;
    public int debitSum;
    public int fileLength;
	
	
	public Validation2(String file) {
		
        StreamFactory factory = StreamFactory.newInstance();
        
        // locate the relative path to this project and store it in the String "path"
        //File currentDirFile = new File(".");
        //String path = currentDirFile.getAbsolutePath().toString(); 
        
        // load the mapping file
        
        // Insert your directory path below
        factory.load("C:\\Users\\Brayden\\Downloads\\FileupLoad (2)\\FileupLoad\\src\\main\\java\\com\\lec\\file\\mapping.xml");
        
        org.beanio.BeanReader in =  factory.createReader("data", new File(file));
        
    	numOfLines = 0; // Current num of lines read
    	debitSum = 0;
    	creditSum = 0;
        
        // Read File header (line 1)
        bean = in.read();
        numOfLines++;
        fileheader = (FileHeader) bean;
        
        // Read Batch Header (line 2)
        bean = (Object) bean;      
        bean = in.read();  
        numOfLines++;
        batchheader = (BatchHeader)bean;
        
        
        //Read each Entry Detail and Sum up Entry Details (for lines 3 -> n)
    	bean = (Object) bean;
    
    	
    	
    	for(int count = 1 ; count <= 18 ; count++) {
    		
    		bean =in.read();
            numOfLines++;
    		entryDetail = (EntryDetail)bean;
    		

    		// check if entry code is a debit (27, 28, 37, 38)
      		if((Integer.parseInt(entryDetail.getTransactionCode()) == 27 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 28 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 37 || 
	    		Integer.parseInt(entryDetail.getTransactionCode()) == 38 ))
	    		
      			debitSum += Integer.parseInt(entryDetail.getAmount());
      		// Else it is a credit (22, 23, 32, 33)
      		else if((Integer.parseInt(entryDetail.getTransactionCode()) == 22 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 23 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 32 || 
    	    		Integer.parseInt(entryDetail.getTransactionCode()) == 33 ))
      			
	    		creditSum += Integer.parseInt(entryDetail.getAmount());
    	}
    	

    	// Read Company/Batch Control Record Format (for line n+1)
    	// must check creditSum and debitSum against corresponding credit and debit totals
        bean = (Object) bean;      
        bean = in.read();   
        numOfLines++;
        batchcontrol = (BatchControl)bean;
        

        //hash error
        //int hashError = 0;
        //hashError = hashError(routingSum, Double.parseDouble(batchcontrol.getEntryHash()));

    	
    	// Read File Control Record Format (for line n+2)
        bean = (Object) bean;      
        bean = in.read();   
        numOfLines++;
        filecontrol = (FileControl)bean;
        fileLength = Integer.parseInt(filecontrol.getBlockCount()) * 10; // The number of lines the file *should* have
    	
    	
    	// Read Padding lines of zero's for remaining lines until filecontrol.getBlockCount() is divisble by 10 (count % 10 == 0)
    	// Anywhere from 0 (already divisible by 10) 
    	// up to 9 (needs to have 9 additional lines to be divisable by 10)
        bean = (Object)bean;
        while((bean=in.read()) != null ) {
        	padding = (Padding)bean;
        	numOfLines++;
        }

	}
	
	public int hashError(double recieved, double expected) {
		// Checks hash error between and expected value and a recieved 
		
		if(recieved == expected) {
			return 0; 
		}
		else { 
			return 1;	
		}
	}
	
	
}
