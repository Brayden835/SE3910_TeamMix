package com.lec.file;

import java.util.regex.Pattern;

public class VALIDATE_EntryDetail {
    //TRUE indicates ERROR
    //FALSE indicates NO ERROR
	
	public boolean VALIDATE_recordTypeCode(String recordTypeCode) {
       //must be 6
		if(recordTypeCode.equals("6")) return false;
        return true;
	}			
	public boolean VALIDATE_transactionTypeCode(String transactionTypeCode) {
		//must be numeric
        for(int i = 0; i < 2; i++ )
            if(Character.isDigit(transactionTypeCode.charAt(i)) == false) return true;
    return false;
	}	
	public boolean VALIDATE_routingNumber(String routingNumber) {
		//must be numeric
        for(int i = 0; i < 8; i++ )
            if(Character.isDigit(routingNumber.charAt(i)) == false) return true;
    return false;
	}	
	public boolean VALIDATE_routingNumberCheckDigit(String routingNumberCheckDigit) {
		//must be numeric
        if(Character.isDigit(routingNumberCheckDigit.charAt(0)) == false) return true;
        return false;
	}	
	public boolean VALIDATE_receivedInstitutionAccountNumber(String receivedInstitutionAccountNumber) {
        //must be alphanumeric
        if(receivedInstitutionAccountNumber.matches("[A-Za-z0-9]+") == false) return true;
        return false;
	}
	public boolean VALIDATE_dollarAmountTransaction(String dollarAmountTransaction) {
		//must be numeric
        for(int i = 0; i < 10; i++ )
            if(Character.isDigit(dollarAmountTransaction.charAt(i)) == false) return true;
    return false;
	}	
	public boolean VALIDATE_receiverIDNumber(String receiverIDNumber) {
        //must be alphanumeric
        if(receiverIDNumber.matches("[A-Za-z0-9]+") == false) return true;
        return false;
	}
	public boolean VALIDATE_receiverName(String receiverName) {
        //must be alphanumeric
		Boolean check = Pattern.matches("^[a-zA-Z0-9_ ]*$",receiverName);
    	if(check == false) return true;
    	return false;
	}
	public boolean VALIDATE_discreteData(String discretionaryData) {
        //must be blanks
        if(discretionaryData.isEmpty() == false) return true;
        return false;
	}
	public boolean VALIDATE_addendaRecordIndicator(String addendaRecordIndicator) {
		//must be numeric
		Boolean check = Pattern.matches("^[0-1]",addendaRecordIndicator);
    	if(check == false) return true;
    	return false;
		
		//if(addendaRecordIndicator.charAt(0)=='0' 
		
       // if(Character.isDigit(addendaRecordIndicator.charAt(0)) == false) return true;
        //return false;
	}	
	public boolean VALIDATE_traceNumber(String traceNumber) {
		//must be numeric
        for(int i = 0; i < 15; i++ )
            if(Character.isDigit(traceNumber.charAt(i)) == false) return true;
    return false;
	}	
}
